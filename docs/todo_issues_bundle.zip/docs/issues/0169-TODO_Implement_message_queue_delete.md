# [0169] // TODO: Implement message queue delete

**File:** `kernel/src/ipc/mod.rs`
**Line:** 172
**Marker:** TODO
**Suggested Priority:** Medium
**Suggested Owner Role:** Engineer
**Suggested Estimate (hours):** 16
**Suggested Labels:** `medium;todo`

## Context

```
169: 
170: /// Delete message queue
171: pub fn msg_delete(queue_id: u32) -> bool {
172:     // TODO: Implement message queue delete
173:     true
174: }
175: 
```

## Recommended next steps
- Confirm the owner and adjust scope estimate\- Add unit/integration tests to cover intended behavior
- Produce a PR that either implements the missing behavior or documents a migration if it's a stub
